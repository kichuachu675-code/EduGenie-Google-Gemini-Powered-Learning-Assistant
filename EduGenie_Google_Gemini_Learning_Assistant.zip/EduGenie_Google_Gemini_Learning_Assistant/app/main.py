from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from .learning_engine import generate_learning_content

app = FastAPI(title="EduGenie - Google Gemini Powered Learning Assistant")
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/learn", response_class=HTMLResponse)
async def learn(request: Request, topic: str = Form(...), level: str = Form(...), mode: str = Form(...)):
    result = generate_learning_content(topic.strip(), level, mode)
    return templates.TemplateResponse(
        "result.html",
        {"request": request, "topic": topic.strip(), "level": level, "mode": mode, **result}
    )
