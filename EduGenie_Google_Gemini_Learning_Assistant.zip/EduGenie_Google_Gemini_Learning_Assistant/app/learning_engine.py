def generate_learning_content(topic: str, level: str, mode: str) -> dict:
    topic = topic.strip() or "General Learning"
    level_name = level.title()

    overview = (
        f"{topic} is presented at the {level_name.lower()} level. "
        "Start with the core idea, connect it to examples, and test your understanding."
    )
    explanation = (
        f"Step 1: Understand the definition of {topic}.\n"
        "Step 2: Identify the main concepts and their relationships.\n"
        "Step 3: Work through a small example.\n"
        "Step 4: Explain the idea in your own words.\n"
        "Step 5: Practice questions and review mistakes."
    )
    notes = (
        f"KEY NOTES — {topic}\n\n"
        "• Definition: Learn the central meaning.\n"
        "• Core concepts: Break the topic into smaller ideas.\n"
        "• Application: Find a real-world or academic example.\n"
        "• Review: Summarize without looking at notes.\n"
        "• Practice: Answer questions and revisit weak areas."
    )
    quiz = (
        f"1. What is the main idea behind {topic}?\n"
        "A) An unrelated topic\nB) The core concept\nC) A random process\nD) None\n\n"
        "2. Which approach helps learning?\n"
        "A) Memorize without understanding\nB) Skip examples\nC) Connect concepts with examples\nD) Avoid practice\n\n"
        "3. What should you do after studying?\n"
        "A) Self-test and review mistakes\nB) Stop immediately\nC) Ignore difficult parts\nD) Avoid revision"
    )
    study_plan = (
        f"7-DAY STUDY PLAN — {topic}\n\n"
        "Day 1: Learn definitions and prerequisites.\n"
        "Day 2: Study the main concepts.\n"
        "Day 3: Work through examples.\n"
        "Day 4: Practice questions.\n"
        "Day 5: Review mistakes and difficult concepts.\n"
        "Day 6: Self-test and explain the topic aloud.\n"
        "Day 7: Final revision and mock quiz."
    )
    primary = {"Quiz": quiz, "Study Plan": study_plan, "Notes": notes}.get(mode, explanation)
    return {"overview": overview, "primary": primary, "notes": notes, "quiz": quiz, "study_plan": study_plan}
